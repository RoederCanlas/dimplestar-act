<?php
session_start();

// Simple access restriction (only logged in users can update)
if (!isset($_SESSION['email'])) {
    header("Location: signlog.php");
    exit();
}

$dataFile = "about-data.json";

// Load existing content
$aboutData = [
    "image" => "images/oldbus.jpg",
    "history" => "",
    "statement" => ""
];

if (file_exists($dataFile)) {
    $aboutData = json_decode(file_get_contents($dataFile), true);
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Handle image upload
    if (!empty($_FILES["image"]["name"])) {
        $targetDir = "images/";
        $targetFile = $targetDir . basename($_FILES["image"]["name"]);

        if (move_uploaded_file($_FILES["image"]["tmp_name"], $targetFile)) {
            $aboutData["image"] = $targetFile;
        }
    }

    // Update text content
    $aboutData["history"] = $_POST["history"];
    $aboutData["statement"] = $_POST["statement"];

    // Save to JSON file
    file_put_contents($dataFile, json_encode($aboutData, JSON_PRETTY_PRINT));

    // Redirect back to about.php cleanly
    header("Location: about.php?updated=true");
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Update About Page - Dimple Star Transport</title>
<link rel="stylesheet" type="text/css" href="style/aboutstyle.css" />
<style>
form {
    max-width: 600px;
    margin: 20px auto;
    padding: 20px;
    background: #f5f5f5;
    border-radius: 8px;
}
textarea {
    width: 100%;
    height: 120px;
    padding: 8px;
    margin-top: 5px;
}
input[type="file"], input[type="submit"] {
    margin-top: 10px;
}
.success {
    color: green;
    font-weight: bold;
    text-align: center;
}
</style>
</head>
<body>
<div id="wrapper">
    <div id="header">
        <h1><a href="index.php"><img src="images/logo.png" class="logo" alt="Dimple Star Transport" /></a></h1>
    </div>
    <div id="content">
        <h2 style="text-align:center;">Update About Page Content</h2>

        <form method="post" enctype="multipart/form-data">
            <label>Update Image:</label><br>
            <img src="<?php echo $aboutData['image']; ?>" width="200"><br>
            <input type="file" name="image"><br><br>

            <label>History Content:</label>
            <textarea name="history"><?php echo htmlspecialchars($aboutData['history']); ?></textarea><br>

            <label>Statement Content:</label>
            <textarea name="statement"><?php echo htmlspecialchars($aboutData['statement']); ?></textarea><br>

            <input type="submit" value="Save Updates">
        </form>
    </div>
</div>
</body>
</html>
