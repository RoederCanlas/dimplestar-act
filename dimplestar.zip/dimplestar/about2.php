<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Dimple Star Transport</title>
<link rel="stylesheet" type="text/css" href="style/aboutstyle.css" />
<link rel="icon" href="images/icon.ico" type="image/x-con">
<style>

</style>
</head>
<body>
<div id="wrapper">
	<div id="header">
    <h1><a href="index.php"><img src="images/logo.png" class="logo" alt="Dimple Star Transport" /></a></h1>
        <ul id="mainnav">
			<li><a href="index.php">Home</a></li>
			<li class="current"><a href="about.php">About Us</a></li>
            <li><a href="terminal.php">Terminals</a></li>
			<li><a href="routeschedule.php">Routes / Schedules</a></li>
            <li><a href="contact.php">Contact</a></li>
			<li><a href="book.php">Book Now</a></li>
    	</ul>
	</div>
    <div id="content">
    	<div id="gallerycontainer">
			<div  style="margin:0 auto; padding:30px 20px 20px 20px; width:820px;">	
				<div class="login">
					<div id="right">
						<?php
							session_start();
							if(isset($_SESSION['email'])){
								$email = $_SESSION['email'];
								echo "Welcome,". $email. "!";
								echo "<a href='logout.php'>Logout</a>";
							}
							if(empty($email)){
								echo "<a href='signlog.php'></a>.";
							}?>
					</div>
				</div><div id="right">
						<h3><?php include_once("php_includes/date_time.php"); ?></h3>
					</div>
		<br><br><br>
		
					<img style="border-radius: 8px; box-shadow: 0px 4px 10px rgba(0,0,0,0.3);" src="images/oldbus.jpg" alt="oldbus" width="600">
				<div id ="fb">
					<?php include_once("php_includes/fblike.php"); ?>
				</div>
<div id="statement">
				<h3 style="text-align: center; margin-top: 10px;">History</h3>
<p>
  &nbsp&nbsp&nbsp&nbsp&nbspPhoto taken on <strong>October 16, 1993</strong>. Napat Transit (now Dimple Star Transport) bus with plate 
  <strong>NVR-963</strong> (fleet No. 800) was going to Alabang along with jeepneys under the Light Rail Line in Taft Ave 
  near United Nations Avenue, Ermita, Manila, Philippines.
</p>
<p>
  In <strong>May 2004</strong>, changes were made and <strong>Napat Transit became Dimple Star Transport</strong>.
</p>
<br>
<h3 style="text-align: center;">What is Dimple Star Transport?</h3>
<p>
  &nbsp&nbsp&nbsp&nbsp&nbspDimple Star Transport began as <strong>City Operations Transport Napat Express</strong>, founded by Hilbert Napat, 
  operating between Lawton and Alabang in Metro Manila. Following developments in the nation’s nautical infrastructure in the early 2000s, it expanded services to include provincial routes from Cubao and Pasay to Iloilo and Mindoro, including ferry-assisted crossings through Calapan and Abra de Ilog.
</p>
<p>
  <br>&nbsp&nbsp&nbsp&nbsp Tragically, the company became embroiled in a catastrophic accident in <strong>March 2018</strong> when one of its rebuilt buses—constructed from junkyard parts—plummeted into a ravine in Sablayan, Occidental Mindoro, resulting in <strong>19 deaths</strong> and multiple injuries.
</p>
<p>
  In response, the LTFRB imposed a <strong>30-day preventive suspension</strong> on its entire 118-unit fleet. Law enforcement also impounded dozens of its buses, and local authorities shut down its terminals for permit violations. By <strong>December 2018</strong>, the company’s franchise had been revoked, marking the end of its operations.
</p>
						
			<table style="width:75%; text-align:left;">
  <tr>
    <td style="padding-right:40px;">
      <h3 style="text-align: center;">Mission</h3>
      To provide superior transport service to Metro Manila and Mindoro Province commuters.
    </td>
    <td>
      <h3 style="text-align: center;">Vision</h3>
      To lead the bus transport industry through its innovation service to the riding public.
    </td>
  </tr>
  </div>
</table>
				  
				<div class="column-clear"></div>
            </div>
				<div class="clearfix"></div>
        </div>
    </div>
   
<div id="footer">
	<a href="index.php"><img src="images/footer-logo.jpg" alt="Dimple Star Transport" /></a>
	<p>&copy;Dimple Star Transport<br /></p>
</div>

</div>
</body>
</html>