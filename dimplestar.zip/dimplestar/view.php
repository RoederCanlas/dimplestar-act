<?php
	include 'php_includes/connection.php';
?>
<html>
	<head>
	</head>
	<body>
		<?php
			include 'php_includes/buslist.php';
		?>
	</body>
</html>