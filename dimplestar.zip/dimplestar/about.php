<?php
session_start();

// Load dynamic content from JSON file
$dataFile = "about-data.json";
if (file_exists($dataFile)) {
    $aboutData = json_decode(file_get_contents($dataFile), true);
} else {
    // Defaults if no data file yet
    $aboutData = [
        "image" => "images/oldbus.jpg",
        "history" => "Default history text here...",
        "statement" => "Default statement text here..."
    ];
}
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Dimple Star Transport</title>
<link rel="stylesheet" type="text/css" href="style/aboutstyle.css" />
<link rel="icon" href="images/icon.ico" type="image/x-con">
</head>
<body>
<div id="wrapper">
	<div id="header">
        <h1><a href="index.php"><img src="images/logo.png" class="logo" alt="Dimple Star Transport" /></a></h1>
        <ul id="mainnav">
			<li><a href="index.php">Home</a></li>
			<li class="current"><a href="about.php">About Us</a></li>
            <li><a href="terminal.php">Terminals</a></li>
			<li><a href="routeschedule.php">Routes / Schedules</a></li>
            <li><a href="contact.php">Contact</a></li>
			<li><a href="book.php">Book Now</a></li>
    	</ul>
	</div>

    <div id="content">
    	<div id="gallerycontainer">
			<div style="margin:0 auto; padding:30px 20px 20px 20px; width:820px;">	

				<!-- User Login / Session -->
				<div class="login">
					<div id="right">
						<?php
							if(isset($_SESSION['email'])){
								$email = $_SESSION['email'];
								echo "Welcome, ". $email. "!";
								echo " <a href='logout.php'>Logout</a>";
							} else {
								echo "<a href='signlog.php'>Login</a>";
							}
						?>
					</div>
				</div>

				<!-- Date and Update Button -->
				<div id="right">
					<h3><?php include_once("php_includes/date_time.php"); ?></h3>
					<button id="update-btn" name="update-btn" onclick="window.location.href='about-update.php'">
						Update details
					</button>
				</div>

				<br><br><br>

				<!-- Dynamic Image -->
				<img style="border-radius: 8px; box-shadow: 0px 4px 10px rgba(0,0,0,0.3);" 
					 src="<?php echo $aboutData['image']; ?>" 
					 alt="about-image" width="600">

				<!-- Facebook Like -->
				<div id="fb">
					<?php include_once("php_includes/fblike.php"); ?>
				</div>

				<!-- Dynamic Content -->
				<div id="statement">
					<h3 style="text-align: center; margin-top: 10px;">History</h3>
					<p><?php echo nl2br($aboutData['history']); ?></p>

					<h3 style="text-align: center;">What is Dimple Star Transport?</h3>
					<p><?php echo nl2br($aboutData['statement']); ?></p>
				</div>

				<!-- Mission and Vision -->
				<table style="width:75%; text-align:left;">
					<tr>
						<td style="padding-right:40px;">
							<h3 style="text-align: center;">Mission</h3>
							To provide superior transport service to Metro Manila and Mindoro Province commuters.
						</td>
						<td>
							<h3 style="text-align: center;">Vision</h3>
							To lead the bus transport industry through its innovation service to the riding public.
						</td>
					</tr>
				</table>

				<div class="column-clear"></div>
            </div>
			<div class="clearfix"></div>
        </div>
    </div>

	<!-- Footer -->
	<div id="footer">
		<a href="index.php"><img src="images/footer-logo.jpg" alt="Dimple Star Transport" /></a>
		<p>&copy; Dimple Star Transport<br /></p>
	</div>
</div>
</body>
</html>
