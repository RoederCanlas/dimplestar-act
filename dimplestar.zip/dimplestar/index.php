<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Dimple Star Transport</title>
<link rel="stylesheet" type="text/css" href="style/indexstyle.css" />
<link rel="icon" href="images/icon.ico" type="image/x-con">
<script src="slide/js/jquery.js"></script>
<script src="slide/js/amazingslider.js"></script>
<script src="slide/js/initslider-1.js"></script>
</head>
<body>
<div id="wrapper">
	<div id="header">
    <h1><a href="index.php"><img src="images/logo.png" class="logo" alt="Dimple Star Transport" /></a></h1>
        <ul id="mainnav">
			<li class="current"><a href="index.php">Home</a></li>
			<li><a href="about.php">About Us</a></li>
            <li><a href="terminal.php">Terminals</a></li>
			<li><a href="routeschedule.php">Routes / Schedules</a></li>
            <li><a href="contact.php">Contact</a></li>
			<li><a href="book.php">Book Now</a></li>
    	</ul>
	</div>
    <div id="content">
    	<div id="gallerycontainer">
			<div style="margin:10 auto; padding:30px 20px 20px 20px;">	
				<div class="login">
					<div id="right">
						<?php
							session_start();
							if(isset($_SESSION['email'])){
								$email = $_SESSION['email'];
								echo "Welcome,". $email. "!";
								echo "<a href='logout.php'>Logout</a>";
							}
							if(empty($email)){
								echo "<a href='signlog.php'>SignUp / Login</a>.";
							}?>
					</div>
				</div>
				<div style="margin:0px auto;max-width:1024px;">
					<div class="carousel">
						<div class="carousel-track">
							<div class="carousel-slide"><img src="slide/images/b1.png" alt="Bus 1"></div>
							<div class="carousel-slide"><img src="slide/images/b2.png" alt="Bus 2"></div>
							<div class="carousel-slide"><img src="slide/images/b3.png" alt="Bus 3"></div>
							<div class="carousel-slide"><img src="slide/images/b4.png" alt="Bus 4"></div>
						</div>
					  <button class="carousel-btn prev">&#10094;</button>
					  <button class="carousel-btn next">&#10095;</button>
					</div>
				</div>

<script>
document.addEventListener("DOMContentLoaded", () => {
  const track = document.querySelector('.carousel-track');
  const slides = Array.from(track.children);
  const nextBtn = document.querySelector('.carousel-btn.next');
  const prevBtn = document.querySelector('.carousel-btn.prev');

  let currentIndex = 0;

  function updateCarousel() {
    track.style.transform = `translateX(-${currentIndex * 100}%)`;
  }

  nextBtn.addEventListener('click', () => {
    currentIndex = (currentIndex + 1) % slides.length;
    updateCarousel();
  });

  prevBtn.addEventListener('click', () => {
    currentIndex = (currentIndex - 1 + slides.length) % slides.length;
    updateCarousel();
  });

  // Auto-slide every 4s
  setInterval(() => {
    currentIndex = (currentIndex + 1) % slides.length;
    updateCarousel();
  }, 4000);
});
</script>

<div class="contact-info">
  <h3>Contact us at:</h3>
  <h2>0929 209 0712</h2>
  <p>
    Block 1 lot 10, southpoint Subd.<br>
    Brgy Banay-Banay, Cabuyao, Laguna
  </p>
</div>

	<div id="right">
		<h3><?php include_once("php_includes/date_time.php"); ?></h3>
	</div>			
				<div class="column-clear"></div>
            </div>
				<div class="clearfix"></div>
        </div>
    </div>    
<div id="footer">
	<a href="index.php"><img src="images/footer-logo.jpg" alt="Dimple Star Transport" /></a>
	<p>&copy;Dimple Star Transport<br /></p>
</div>

</div>
</body>
</html>